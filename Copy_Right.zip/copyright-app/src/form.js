// import React, { useState } from "react";

// import Form from "react-bootstrap/Form";
// import { Button, Alert } from "react-bootstrap";
// import axios from "axios";

// import "bootstrap/dist/css/bootstrap.css";
// import "./App.css";

// const input = {
//   color: "charcol",
//   fontSize: "16px",
//   fontWeight: "bold",
// };

// function Sample() {
//   const [formData, setFormData] = useState("");
//   const [submitted, setSubmitted] = useState(false);
//   const [file, setFile] = useState();

//   const handleSubmit = (e) => {
//     e.preventDefault();
//     setSubmitted(true);

//     // Send the form data to the backend
//     axios
//       .post("/api/data", { formData })
//       .then((response) => console.log(response.data))
//       .catch((error) => console.log(error));
//   };

//   function handleChange(e) {
//     console.log(e.target.files);
//     setFile(URL.createObjectURL(e.target.files[0]));
//   }

//   console.log({ formData });

//   return (
//     <div className="container">
//       <h2>Inventive Research Organization</h2>
//       <hr />
//       <h4>Copyright Transfer</h4>
//       <br />
//       <Form onSubmit={handleSubmit}>
//         <Form.Group controlId="nameInput">
//           <Form.Label style={input}>Enter Your Name:</Form.Label>
//           <Form.Control
//             type="text"
//             placeholder=" (all author’s name in  capital letters)"
//             style={{ textTransform: "uppercase" }}
//           />
//         </Form.Group>{" "}
//         <br />
//         <Form.Group controlId="nameInput">
//           <Form.Label style={input}>Enter Your Title:</Form.Label>
//           <Form.Control
//             type="text"
//             placeholder="paper entitled (in  capital letters)"
//             style={{ textTransform: "uppercase" }}
//           />
//         </Form.Group>{" "}
//         <br />
//         <Form.Group controlId="journalSelect">
//           <Form.Label style={input}>Select Journal Names:</Form.Label>
//           <Form.Control as="select">
//             <option disabled selected>Select Journal Names:</option>
//             <option>
//               Journal on Artificial Intelligence and Capsule Networks
//             </option>
// <option>IRO Journal on Sustainable Wireless Systems</option>
// <option>
//   Journal on IoT in Social, Mobile, Analytics, and Cloud
// </option>
// <option>Journal on Electronics and Informatics</option>
// <option>Journal on Electrical Engineering and Automation</option>
// <option>Journal on Innovative Image Processing</option>
// <option>Journal on Soft Computing Paradigm</option>
// <option>
//   Journal on Ubiquitous Computing and Communication Technologies
// </option>
// <option>
//   Journal on Trends in Computer Science and Smart Technology
// </option>
// <option>Journal on Information Technology and Digital World</option>
// <option>Recent Research Reviews Journal</option>
//           </Form.Control>
//         </Form.Group>{" "}
//         <br />
//         <Form.Group controlId="licenseType">
//           <Form.Label style={input}>License Type:</Form.Label>

//           {["radio"].map((type) => (
//             <div key={`inline-${type}`} className="mb-3">
//               <Form.Check
//                 inline
//                 label="Green Open Access"
//                 name="group1"
//                 type={type}
//                 id={`inline-${type}-1`}
//               />
//               <Form.Check
//                 inline
//                 label="Gold Open Access"
//                 name="group1"
//                 type={type}
//                 id={`inline-${type}-2`}
//               />
//             </div>
//           ))}
//         </Form.Group>{" "}
//         <Form.Group controlId="dateInput">
//           <Form.Label style={input}>Date:</Form.Label>
//           <Form.Control
//             type="text"
//             value={new Date().toLocaleDateString()}
//             readOnly
//           />
//         </Form.Group>{" "}
//         <br />
//         <Form.Group controlId="nameInput">
//           <Form.Label style={input}>Signature and Name:</Form.Label>
//           <Form.Control type="text" placeholder="Enter your name" />
//         </Form.Group>{" "}
//         <br />
//         <Form.Group controlId="imageUpload">
//           <Form.Label style={input}>Upload Signature Image:</Form.Label>
//           <Form.Control
//             type="file"
//             accept="image/*"
//             onChange={handleChange}
//           />{" "}
//           <br />
//           <br /> <img src={file} width="150" height="80" />
//         </Form.Group>{" "}
//         <br />

//         <div className="text-center">
//           <Button variant="primary" type="submit">
//             Submit
//           </Button>
//         </div>
//         {submitted && (
//           <Alert variant="success" className="mt-3 ">
//             Form submitted successfully!
//           </Alert>
//         )}
//       </Form>
//     </div>
//   );
// }

// export default Sample;

// // {
// //   /* // <div className="App">
// //     //   <h1>Copy Right Form</h1>
// //     //   <form onSubmit={handleSubmit}>
// //     //     <input type="text" value={formData} onChange={e => setFormData(e.target.value)} />
// //     //     <button type="submit">Submit</button>
// //     //   </form>
// //     // </div> */
// // }

// import React, { useState } from "react";

// import Form from "react-bootstrap/Form";
// import { Button, Alert } from "react-bootstrap";
// import axios from "axios";
// import swal from "sweetalert";

// import "bootstrap/dist/css/bootstrap.css";
// import "./App.css";

// const input = {
//   color: "charcol",
//   fontSize: "16px",
//   fontWeight: "bold",
// };

// function Sample() {
//   const [formData, setFormData] = useState({});
//   const [submitted, setSubmitted] = useState(false);
//   const [file, setFile] = useState();
//   const [name, setName] = useState("");
//   const [errors, setErrors] = useState("");

//   const handleNameChange = (e) => {
//     setName(e.target.value);
//   };

//   const validateForm = () => {
//     const { name, title, journal, license, signature, file } = formData;
//     if (!name || !title || !journal || !license || !signature || !file) {
//       // alert("Please fill in all required fields.");
//       swal("Failed!", "Please fill in all required fields!", "error");

//       return false;
//     }
//     return true;
//   };

//   const handleSubmit = (e) => {
//     e.preventDefault();

//     if (validateForm()) {
//       setSubmitted(true);
//       // Send the form data to the backend
//       axios
//         .post("/api/data", formData)

//         .then((response) => console.log(response.data))
//         .catch((error) => console.log(error));
//     }
//   };

//   const handleChange = (e) => {
//     const { name, value } = e.target;
//     setFormData((prevState) => ({ ...prevState, [name]: value }));
//     console.log(name, value);
//   };

//   const handleFileChange = (e) => {
//     const selectedFile = e.target.files[0];
//     setFile(URL.createObjectURL(selectedFile));
//     setFormData((prevState) => ({ ...prevState, signature: selectedFile }));
//   };

//   return (
//     <div className="container">
//       <h2>Inventive Research Organization</h2>
//       <hr />
//       <h4>Copyright Transfer</h4>
//       <br />
//       <Form onSubmit={handleSubmit}>
//         <Form.Group controlId="nameInput">
//           <Form.Label style={input}>Enter Your Name:</Form.Label>
//           <Form.Control
//             type="text"
//             placeholder=" (all author’s name in capital letters)"
//             style={{ textTransform: "uppercase" }}
//             name="name"
//             onChange={handleChange}
//           />
//         </Form.Group>
//         <br />
//         <Form.Group controlId="titleInput">
//           <Form.Label style={input}>Enter Your Title:</Form.Label>
//           <Form.Control
//             type="text"
//             placeholder="paper entitled (in capital letters)"
//             style={{ textTransform: "uppercase" }}
//             name="title"
//             onChange={handleChange}
//           />
//         </Form.Group>
//         <br />
//         <Form.Group controlId="journalSelect">
//           <Form.Label style={input}>Select Journal Names:</Form.Label>
//           <Form.Control as="select" name="journal" onChange={handleChange}>
// <option disabled selected>
//   Select Journal Names:
// </option>
// <option>
//   Journal on Artificial Intelligence and Capsule Networks
// </option>
// <option>IRO Journal on Sustainable Wireless Systems</option>
// <option>
//   Journal on IoT in Social, Mobile, Analytics, and Cloud
// </option>
// <option>Journal on Electronics and Informatics</option>
// <option>Journal on Electrical Engineering and Automation</option>
// <option>Journal on Innovative Image Processing</option>
// <option>Journal on Soft Computing Paradigm</option>
// <option>
//   Journal on Ubiquitous Computing and Communication Technologies
// </option>
// <option>
//   Journal on Trends in Computer Science and Smart Technology
// </option>
// <option>Journal on Information Technology and Digital World</option>
// <option>Recent Research Reviews Journal</option>
//           </Form.Control>
//         </Form.Group>
//         <br />
//         <Form.Group controlId="licenseType">
//           <Form.Label style={input}>License Type:</Form.Label>
//           {["Green Open Access", "Gold Open Access"].map((licenseType) => (
//             <div key={licenseType} className="mb-3">
//               <Form.Check
//                 inline
//                 label={licenseType}
//                 name="license"
//                 type="radio"
//                 id={`inline-${licenseType}`}
//                 value={licenseType}
//                 onChange={handleChange}
//               />
//             </div>
//           ))}
//         </Form.Group>
//         <Form.Group controlId="dateInput">
//           <Form.Label style={input}>Date:</Form.Label>
//           <Form.Control
//             type="text"
//             value={new Date().toLocaleDateString()}
//             readOnly
//           />
//         </Form.Group>
//         <br />
//         <Form.Group controlId="signatureInput">
//           <Form.Label style={input}>Signature and Name:</Form.Label>
//           <Form.Control
//             type="text"
//             placeholder="Enter your name"
//             name="signature"
//             onChange={handleChange}
//           />
//         </Form.Group>
//         <br />
//         <Form.Group controlId="imageUpload">
//           <Form.Label style={input}>Upload Signature Image:</Form.Label>
//           <Form.Control
//             type="file"
//             name="image"
//             accept="image/*"
//             onChange={handleFileChange}
//             value={file}
//           />
//           <br />
//           <br />
//           <img src={file} width="150" height="80" alt="Uploaded Signature" />
//         </Form.Group>
//         <br />
//         <div className="text-center">
//           <Button variant="primary" type="submit">
//             Submit
//           </Button>
//         </div>
//         {submitted && (
//           <Alert variant="success" className="mt-3 ">
//             Form submitted successfully!
//           </Alert>
//         )}
//       </Form>
//     </div>
//   );
// }

// export default Sample;
















import React, { useState } from "react";

import { Form, Button, Alert } from "react-bootstrap";
import axios from "axios";
import swal from "sweetalert";

import "bootstrap/dist/css/bootstrap.css";
import "./App.css";

const input = {
  color: "charcoal",
  fontSize: "16px",
  fontWeight: "bold",
};

function Sample() {
  const [formData, setFormData] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const [file, setFile] = useState();
  const [name, setName] = useState("");
  const [errors, setErrors] = useState({});

  const handleNameChange = (e) => {
    setName(e.target.value);
  };

  const validateForm = () => {
    const { name, title, journal, license, signature, file } = formData;
    console.log(formData);
    const errors = {};

    if (!name) {
      errors.name = "Please enter your name.";
    }

    if (!title) {
      errors.title = "Please enter your title.";
    }

    if (!journal) {
      errors.journal = "Please select a journal.";
    }

    if (!license) {
      errors.license = "Please select a license type.";
    }

    if (!signature) {
      errors.signature = "Please enter your signature.";
    }

    // if (!file) {
    //   errors.file = "Please upload a signature image.";
    // }

    setErrors(errors);

    return Object.keys(errors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (validateForm()) {
      setSubmitted(true);
      // Send the form data to the backend
     
    } 
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevState) => ({ ...prevState, [name]: value }));
  };

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    setFile(URL.createObjectURL(selectedFile));
    setFormData((prevState) => ({ ...prevState, signature: selectedFile }));
  };

  return (
    <div className="container">
      <h2>Inventive Research Organization</h2>
      <hr />
      <h4>Copyright Transfer</h4>
      <br />
      <Form onSubmit={handleSubmit}>
        <Form.Group controlId="nameInput">
          <Form.Label style={input}>Enter Your Name:</Form.Label>
          <Form.Control
            type="text"
            placeholder=" (all author’s name in capital letters)"
            style={{ textTransform: "uppercase" }}
            name="name"
            onChange={handleChange}
            isInvalid={!!errors.name}
          />
          <Form.Control.Feedback type="invalid">
            {errors.name}
          </Form.Control.Feedback>
        </Form.Group>
        <br />
        <Form.Group controlId="titleInput">
          <Form.Label style={input}>Enter Your Title:</Form.Label>
          <Form.Control
            type="text"
            placeholder="paper entitled (in capital letters)"
            style={{ textTransform: "uppercase" }}
            name="title"
            onChange={handleChange}
            isInvalid={!!errors.title}
          />
          <Form.Control.Feedback type="invalid">
            {errors.title}
          </Form.Control.Feedback>
        </Form.Group>
        <br />
        <Form.Group controlId="journalSelect">
          <Form.Label style={input}>Select Journal Names:</Form.Label>
          <Form.Control
            as="select"
            name="journal"
            onChange={handleChange}
            isInvalid={!!errors.journal}
          >
            <option disabled selected>
              Select Journal Names:
            </option>
            <option>
              Journal on Artificial Intelligence and Capsule Networks
            </option>
            <option>IRO Journal on Sustainable Wireless Systems</option>
            <option>
              Journal on IoT in Social, Mobile, Analytics, and Cloud
            </option>
            <option>Journal on Electronics and Informatics</option>
            <option>Journal on Electrical Engineering and Automation</option>
            <option>Journal on Innovative Image Processing</option>
            <option>Journal on Soft Computing Paradigm</option>
            <option>
              Journal on Ubiquitous Computing and Communication Technologies
            </option>
            <option>
              Journal on Trends in Computer Science and Smart Technology
            </option>
            <option>Journal on Information Technology and Digital World</option>
            <option>Recent Research Reviews Journal</option>
            {/* Other options */}
          </Form.Control>
          <Form.Control.Feedback type="invalid">
            {errors.journal}
          </Form.Control.Feedback>
        </Form.Group>
        <br />
        <Form.Group controlId="licenseType">
          <Form.Label style={input}>License Type:</Form.Label>
          {["Green Open Access", "Gold Open Access"].map((licenseType) => (
            <div key={licenseType} className="mb-3">
              <Form.Check
                inline
                label={licenseType}
                name="license"
                type="radio"
                id={`inline-${licenseType}`}
                value={licenseType}
                onChange={handleChange}
                isInvalid={!!errors.license}
              />
            </div>
          ))}
          <Form.Control.Feedback type="invalid">
            {errors.license}
          </Form.Control.Feedback>
        </Form.Group>
        <Form.Group controlId="dateInput">
          <Form.Label style={input}>Date:</Form.Label>
          <Form.Control
            type="text"
            value={new Date().toLocaleDateString()}
            readOnly
          />
        </Form.Group>
        <br />
        <Form.Group controlId="signatureInput">
          <Form.Label style={input}>Signature and Name:</Form.Label>
          <Form.Control
            type="text"
            placeholder="Enter your name"
            name="signature"
            onChange={handleChange}
            isInvalid={!!errors.signature}
          />
          <Form.Control.Feedback type="invalid">
            {errors.signature}
          </Form.Control.Feedback>
        </Form.Group>
        <br />

        <Form.Group controlId="imageUpload">
          <Form.Label style={input}>Upload Signature Image:</Form.Label>
          <div>
            <Form.Control
              type="file"
              name="image"
              accept="image/*"
              onChange={handleFileChange}
              // isInvalid={!!errors.file}
            />
            {/* {errors.file && (
      <Form.Control.Feedback type="invalid">
        {errors.file}
      </Form.Control.Feedback>
    )} */}
          </div>

          {file && (
            <div className="mt-3">
              <img
                src={file}
                width="150"
                height="80"
                alt="Uploaded Signature"
              />
            </div>
          )}
        </Form.Group>

        <br />
        <div className="text-center">
          <Button variant="primary" type="submit">
            Submit
          </Button>
        </div>
        {submitted && (
          <Alert variant="success" className="mt-3">
            Form submitted successfully!
          </Alert>
        )}
      </Form>
    </div>
  );
}

export default Sample;













