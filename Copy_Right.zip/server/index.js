const express = require("express");
const app = express();
const port = 4000;

app.use(express.json());

app.post("/api/data", (req, res) => {
  const { formData } = req.body;
  console.log(formData); // Do something with the form data
  res.send("Data received on the backend!");
});

app.listen(port, () =>
  console.log(`Backend server listening on port ${port}!`)
);
